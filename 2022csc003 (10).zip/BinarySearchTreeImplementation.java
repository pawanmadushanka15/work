class Node {
    int data;
    Node left, right;

    public Node(int data) {
        this.data = data;
        left = right = null;
    }
}

class BinarySearchTree {
    Node root;

    public BinarySearchTree() {
        root = null;
    }

    public Node insert(Node root, int data) {
        if (root == null) {
            root = new Node(data);
            return root;
        }
        if (data < root.data) {
            root.left = insert(root.left, data);
        } else if (data > root.data) {
            root.right = insert(root.right, data);
        }
        return root;
    }

    public void inorder(Node root) {
        if (root != null) {
            inorder(root.left);
            System.out.print(root.data + " ");
            inorder(root.right);
        }
    }

    public void preorder(Node root) {
        if (root != null) {
            System.out.print(root.data + " ");
            preorder(root.left);
            preorder(root.right);
        }
    }

    public void postorder(Node root) {
        if (root != null) {
            postorder(root.left);
            postorder(root.right);
            System.out.print(root.data + " ");
        }
    }

    public boolean search(Node root, int key) {
        if (root == null) return false;
        if (key == root.data) return true;
        else if (key < root.data) return search(root.left, key);
        else return search(root.right, key);
    }

    public int findMin(Node root) {
        if (root == null) throw new RuntimeException("Tree is empty");
        while (root.left != null) {
            root = root.left;
        }
        return root.data;
    }

    public int findMax(Node root) {
        if (root == null) throw new RuntimeException("Tree is empty");
        while (root.right != null) {
            root = root.right;
        }
        return root.data;
    }
    
    public Node delete(Node root, int key) {
        if (root == null) return root;

        if (key < root.data) {
            root.left = delete(root.left, key);
        } else if (key > root.data) {
            root.right = delete(root.right, key);
        } else {
            // Case 1: No child
            if (root.left == null && root.right == null) {
                return null;
            }
            // Case 2: One child
            else if (root.left == null) {
                return root.right;
            } else if (root.right == null) {
                return root.left;
            }
            // Case 3: Two children
            int minValue = findMin(root.right);
            root.data = minValue;
            root.right = delete(root.right, minValue);
        }
        return root;
    }
}

public class BinarySearchTreeImplementation {
    public static void main(String[] args) {
        BinarySearchTree bst = new BinarySearchTree();

        // Insert elements
        int[] elements = {50, 30, 70, 20, 40, 60, 80};
        for (int el : elements) {
            bst.root = bst.insert(bst.root, el);
        }

        // Display traversals
        System.out.print("Inorder Traversal: ");
        bst.inorder(bst.root);
        System.out.println();

        System.out.print("Preorder Traversal: ");
        bst.preorder(bst.root);
        System.out.println();

        System.out.print("Postorder Traversal: ");
        bst.postorder(bst.root);
        System.out.println();

        // Search for elements
        System.out.println("Search 40: " + bst.search(bst.root, 40));
        System.out.println("Search 90: " + bst.search(bst.root, 90));

        // Min and Max
        System.out.println("Minimum value: " + bst.findMin(bst.root));
        System.out.println("Maximum value: " + bst.findMax(bst.root));

        // Delete nodes
        bst.root = bst.delete(bst.root, 80);
        bst.root = bst.delete(bst.root, 70);
        bst.root = bst.delete(bst.root, 30);

        // Display again after deletion
        System.out.print("Inorder after deletions: ");
        bst.inorder(bst.root);
        System.out.println();
    }
}
